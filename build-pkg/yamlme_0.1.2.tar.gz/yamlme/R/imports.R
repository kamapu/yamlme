#' @importFrom methods setOldClass
#' @importFrom rlist list.flatten
NULL
