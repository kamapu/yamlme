#' @importFrom methods setOldClass
#' @importFrom rmarkdown render
#' @importFrom tools file_path_sans_ext
#' @importFrom yaml as.yaml yaml.load
NULL
